-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2021 at 10:57 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webbanhang`
--
CREATE DATABASE IF NOT EXISTS `webbanhang` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `webbanhang`;

-- --------------------------------------------------------

--
-- Table structure for table `binhluan`
--

CREATE TABLE `binhluan` (
  `IdBinhLuan` int(10) UNSIGNED NOT NULL,
  `NoiDung` varchar(255) NOT NULL,
  `IdUser` int(10) UNSIGNED NOT NULL,
  `IdSanPham` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `binhluan`
--

INSERT INTO `binhluan` (`IdBinhLuan`, `NoiDung`, `IdUser`, `IdSanPham`, `created_at`, `updated_at`) VALUES
(3, 'mẫu này còn màu xanh ko ad', 27, 1, '2020-12-21 11:00:50', NULL),
(19, 'sadsadsa', 27, 1, '2020-12-21 11:00:50', NULL),
(29, 'dsadsa', 27, 68, '2021-01-08 07:08:01', NULL),
(30, 'nguyễn văn trung', 27, 68, '2021-01-08 07:31:15', NULL),
(31, 'đồng hồ đẹp quá shop ơi', 27, 22, '2021-01-08 07:36:42', NULL),
(32, 'hdhsadhsadhsah', 27, 45, '2021-01-08 07:42:30', NULL),
(33, 'mẫu này còn không ạ', 5, 68, '2021-01-08 07:44:45', NULL),
(34, 'trung văn nguyễn', 5, 1, '2021-01-08 09:13:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `danhmuc`
--

CREATE TABLE `danhmuc` (
  `IdDanhMuc` int(10) UNSIGNED NOT NULL,
  `TenDanhMuc` varchar(255) NOT NULL,
  `TenKhongDau` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `danhmuc`
--

INSERT INTO `danhmuc` (`IdDanhMuc`, `TenDanhMuc`, `TenKhongDau`, `created_at`, `updated_at`) VALUES
(42, 'Quần Áo', 'Quan-Ao', '2020-12-10 16:01:35', NULL),
(49, 'Giày Dép', 'Giay-Dep', '2020-12-10 16:34:06', NULL),
(51, 'Phụ Kiện', 'Phu-Kien', '2020-12-10 16:34:23', NULL),
(52, 'Xu Hướng', 'Xu-Huong', '2020-12-10 16:34:31', '2020-12-16 03:00:45'),
(83, 'Thịnh Hành', 'Thinh-Hanh', '2020-12-29 15:46:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `donhang`
--

CREATE TABLE `donhang` (
  `IdDonHang` int(10) UNSIGNED NOT NULL,
  `TrangThai` int(10) UNSIGNED NOT NULL,
  `IdUser` int(10) UNSIGNED NOT NULL,
  `ngaydat` timestamp NULL DEFAULT NULL,
  `ngaychotdon` timestamp NULL DEFAULT NULL,
  `TongTien` varchar(45) NOT NULL,
  `ngayhuy` timestamp NULL DEFAULT NULL,
  `ngaynhan` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donhang`
--

INSERT INTO `donhang` (`IdDonHang`, `TrangThai`, `IdUser`, `ngaydat`, `ngaychotdon`, `TongTien`, `ngayhuy`, `ngaynhan`) VALUES
(44, 0, 27, '2021-01-05 03:32:18', NULL, '1.980.000đ', NULL, NULL),
(47, 2, 27, '2021-01-05 04:11:08', '2021-01-06 02:42:37', '1.280.000đ', NULL, NULL),
(48, 3, 27, '2021-01-05 04:12:27', NULL, '600.000đ', '2021-01-05 04:16:24', NULL),
(50, 0, 27, '2021-01-06 08:24:45', NULL, '480.000đ', NULL, NULL),
(51, 0, 2, '2021-01-06 08:27:59', NULL, '630.000đ', NULL, NULL),
(52, 0, 31, '2021-01-11 08:13:23', NULL, '480.000đ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `donhang_sp`
--

CREATE TABLE `donhang_sp` (
  `IdDonHangSp` int(10) UNSIGNED NOT NULL,
  `IdDonHang` int(10) UNSIGNED NOT NULL,
  `IdSanPham` int(10) UNSIGNED NOT NULL,
  `SoLuongSanPham` int(10) UNSIGNED NOT NULL,
  `SizeSanPham` varchar(10) DEFAULT NULL,
  `DonGiaSanPham` varchar(30) NOT NULL,
  `ThanhTienSanPham` varchar(30) NOT NULL,
  `HinhAnh` varchar(255) NOT NULL,
  `TenSanPham` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donhang_sp`
--

INSERT INTO `donhang_sp` (`IdDonHangSp`, `IdDonHang`, `IdSanPham`, `SoLuongSanPham`, `SizeSanPham`, `DonGiaSanPham`, `ThanhTienSanPham`, `HinhAnh`, `TenSanPham`) VALUES
(2, 44, 52, 5, 'XL', '190.000đ', '950.000đ', './public/upload/sanpham/p3bmjpqbka8qgfo2apple watch.jpg', 'Áo thun có cổ'),
(3, 44, 26, 5, '0', '200.000đ', '1.000.000đ', './public/upload/sanpham/5iwxc2quanao.jpg', 'Áo sơ mi nam 7'),
(6, 47, 44, 5, 'L', '250.000đ', '1.250.000đ', './public/upload/sanpham/y85js1aothunden.jpg', 'Áo thun nam'),
(7, 48, 52, 3, 'M', '190.000đ', '570.000đ', './public/upload/sanpham/p3bmjpqbka8qgfo2apple watch.jpg', 'Áo thun có cổ'),
(9, 50, 68, 3, 'L', '150.000đ', '450.000đ', './public/upload/sanpham/vj7vsn3l5nzo8zf1bayern_logo.png', 'Áo sơ mi nam nam'),
(10, 51, 68, 4, 'M', '150.000đ', '600.000đ', './public/upload/sanpham/vj7vsn3l5nzo8zf1bayern_logo.png', 'Áo sơ mi nam nam'),
(11, 52, 68, 3, 'L', '150.000đ', '450.000đ', './public/upload/sanpham/vj7vsn3l5nzo8zf1bayern_logo.png', 'Áo sơ mi nam nam');

-- --------------------------------------------------------

--
-- Table structure for table `hinhanh`
--

CREATE TABLE `hinhanh` (
  `IdHinhAnh` int(10) UNSIGNED NOT NULL,
  `src` varchar(255) NOT NULL,
  `IdSanPham` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hinhanh`
--

INSERT INTO `hinhanh` (`IdHinhAnh`, `src`, `IdSanPham`) VALUES
(1, './public/upload/sanpham/dsahc172282045_1462606710557372_3098015350042656768_n.jpg', 1),
(2, './public/upload/sanpham/5iwxc2quanao.jpg', 1),
(3, './public/upload/sanpham/5iwxc3quanao.jpg', 1),
(4, './public/upload/sanpham/5iwxc4quanao.jpg', 1),
(5, './public/upload/sanpham/5iwxc5quanao.jpg', 1),
(7, './public/upload/sanpham/75f6gsp6.png', 16),
(8, './public/upload/sanpham/75f6gsp7.jpg', 16),
(9, './public/upload/sanpham/75f6gsp8.png', 16),
(10, './public/upload/sanpham/75f6gsp9.jpg', 16),
(11, './public/upload/sanpham/75f6gsp6.png', 16),
(12, './public/upload/sanpham/gtbeg17w57k1apple watch.jpg', 17),
(13, './public/upload/sanpham/oh985u6yipd2xu32tottenham_logo.png', 17),
(14, './public/upload/sanpham/ny5zj8l6jl8kfg73juventus_logo.png', 17),
(15, './public/upload/sanpham/i5rvrxoc51xddty4real_logo.png', 17),
(16, './public/upload/sanpham/robu8kum0zi0ni25mctcity_logo.png', 17),
(17, './public/upload/sanpham/1zppr1barcelona_logo.png', 18),
(18, './public/upload/sanpham/ixwdykkc7as4ou42barcelona_logo.png', 18),
(19, './public/upload/sanpham/uadut3ylzrx4idy3barcelona_logo.png', 18),
(20, './public/upload/sanpham/l0kahuvugzerv974barcelona_logo.png', 18),
(21, './public/upload/sanpham/jp40v08poh6qayr5barcelona_logo.png', 18),
(27, './public/upload/sanpham/9j2zc1aothun.jpg', 20),
(28, './public/upload/sanpham/oa5lu2phukien.jpg', 20),
(29, './public/upload/sanpham/oa5lu3phukien.jpg', 20),
(30, './public/upload/sanpham/oa5lu4phukien.jpg', 20),
(31, './public/upload/sanpham/oa5lu5phukien.jpg', 20),
(32, './public/upload/sanpham/9y6ex1báo cáo.jpg', 21),
(33, './public/upload/sanpham/oa5lu2phukien.jpg', 21),
(34, './public/upload/sanpham/oa5lu3phukien.jpg', 21),
(35, './public/upload/sanpham/oa5lu4phukien.jpg', 21),
(36, './public/upload/sanpham/oa5lu5phukien.jpg', 21),
(37, './public/upload/sanpham/7w57k1apple watch.jpg', 22),
(38, './public/upload/sanpham/1xuwtqpo9za9dqo2sửa.png', 22),
(39, './public/upload/sanpham/vz9c53sb0p9bfaj3save.jpg', 22),
(40, './public/upload/sanpham/96f0v0lfwktjbhl4window.ico', 22),
(41, './public/upload/sanpham/997exn44jla2tt15thoát.png', 22),
(52, './public/upload/sanpham/75f6gsp6.png', 25),
(53, './public/upload/sanpham/75f6gsp7.jpg', 25),
(54, './public/upload/sanpham/75f6gsp8.png', 25),
(55, './public/upload/sanpham/75f6gsp9.jpg', 25),
(56, './public/upload/sanpham/gw92qs241fy0aol5apple watch.jpg', 25),
(57, './public/upload/sanpham/5iwxc2quanao.jpg', 26),
(58, './public/upload/sanpham/5iwxc3quanao.jpg', 26),
(59, './public/upload/sanpham/5iwxc4quanao.jpg', 26),
(60, './public/upload/sanpham/5iwxc5quanao.jpg', 26),
(61, './public/upload/sanpham/lkzdsukxmbldcwd5tottenham_logo.png', 26),
(67, './public/upload/sanpham/y85js1aothunden.jpg', 44),
(68, './public/upload/sanpham/0a7ks1aothunden.jpg', 44),
(69, './public/upload/sanpham/7aheb1aothunden.jpg', 44),
(70, './public/upload/sanpham/hdah71aothunden.jpg', 44),
(71, './public/upload/sanpham/3ydad1aothunden.jpg', 44),
(72, './public/upload/sanpham/s3a65c639yu4ah32banh.jpg', 45),
(73, './public/upload/sanpham/9ahjk1aothun.jpg', 45),
(74, './public/upload/sanpham/hqsk81aothun.jpg', 45),
(75, './public/upload/sanpham/7bdb61aothun.jpg', 45),
(76, './public/upload/sanpham/kojak1aothun.jpg', 45),
(102, './public/upload/sanpham/p3bmjpqbka8qgfo2apple watch.jpg', 52),
(103, './public/upload/sanpham/knrr1hkfc0sf6892apple watch.jpg', 52),
(104, './public/upload/sanpham/e7ptee7rr8ue8wf3aothun.jpg', 52),
(105, './public/upload/sanpham/hr0moy27ccn4ziv1aothun.jpg', 52),
(106, './public/upload/sanpham/ww3n2bjftg7sa551aothun.jpg', 52),
(117, './public/upload/sanpham/i9h3egpg2ixq3q11apple watch.jpg', 57),
(118, './public/upload/sanpham/87d1g42ykzo26ae1apple watch.jpg', 57),
(119, './public/upload/sanpham/6b40aw29acz1v6s1bayern_logo.png', 57),
(120, './public/upload/sanpham/h5adi5xpigz69ze1bayern_logo.png', 57),
(121, './public/upload/sanpham/i24u0spk9t3hrta1barcelona_logo.png', 57),
(122, './public/upload/sanpham/cv37px34ggewwnf1aothun.jpg', 58),
(123, './public/upload/sanpham/apmk7c8f16tmyg41aothun.jpg', 58),
(124, './public/upload/sanpham/wihvs1x3n253jkw1aothun.jpg', 58),
(125, './public/upload/sanpham/43hb0dfdpwrxhu31aothun.jpg', 58),
(126, './public/upload/sanpham/e1c8uuku2l34hl11aothun.jpg', 58),
(127, './public/upload/sanpham/z7tcvit0zwsmrd41banh.jpg', 59),
(128, './public/upload/sanpham/159yavl08wz30sb1person1.jpeg', 59),
(129, './public/upload/sanpham/jsvedwscgo2wboy1person2.jpeg', 59),
(130, './public/upload/sanpham/i73slvtx0oq9gho1barcelona_logo.png', 59),
(131, './public/upload/sanpham/e1ltppekorn756a1bayern_logo.png', 59),
(132, './public/upload/sanpham/hyiibklunxnk9w51apple watch.jpg', 61),
(133, './public/upload/sanpham/v0pzex8h55x6pce1barcelona_logo.png', 61),
(134, './public/upload/sanpham/wgspnyqi038owcs1barcelona_logo.png', 61),
(135, './public/upload/sanpham/k5933btqhmadfhw1bayern_logo.png', 61),
(136, './public/upload/sanpham/ie37sbsmzn7qq5i1mctcity_logo.png', 61),
(137, './public/upload/sanpham/jq94a0w4n0uur1y1apple watch.jpg', 66),
(138, './public/upload/sanpham/dyk46x2f41ewff12apple watch.jpg', 66),
(139, './public/upload/sanpham/rbqkssyn4dnmdm73apple watch.jpg', 66),
(140, './public/upload/sanpham/zsopi8ht2b619224apple watch.jpg', 66),
(141, './public/upload/sanpham/scn7cdoyiv5f5h35banh.jpg', 66),
(142, './public/upload/sanpham/vj7vsn3l5nzo8zf1bayern_logo.png', 68),
(143, './public/upload/sanpham/thjwd82fh75fzy12banh.jpg', 68),
(144, './public/upload/sanpham/6uuqokn33cxwt2f3banh.jpg', 68),
(145, './public/upload/sanpham/36aphjq85mq3qt94banh.jpg', 68),
(146, './public/upload/sanpham/8n37u4so3k1shx95banh.jpg', 68);

-- --------------------------------------------------------

--
-- Table structure for table `kieusize`
--

CREATE TABLE `kieusize` (
  `IdKieuSize` int(10) UNSIGNED NOT NULL,
  `TenKieuSize` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kieusize`
--

INSERT INTO `kieusize` (`IdKieuSize`, `TenKieuSize`, `created_at`, `updated_at`) VALUES
(1, 'Size Quần', '2020-12-15 08:24:49', NULL),
(2, 'Size Áo', '2020-12-15 08:24:49', NULL),
(3, 'Size Giày-Dép', '2020-12-15 08:24:49', NULL),
(4, 'Size Nịt', '2020-12-15 09:54:28', '2020-12-15 09:58:11'),
(5, 'Size Mũ', '2020-12-16 04:01:11', '2020-12-19 14:38:12');

-- --------------------------------------------------------

--
-- Table structure for table `phanhoi`
--

CREATE TABLE `phanhoi` (
  `IdPhanHoi` int(10) UNSIGNED NOT NULL,
  `NoiDung` varchar(255) NOT NULL,
  `IdUser` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phanhoi`
--

INSERT INTO `phanhoi` (`IdPhanHoi`, `NoiDung`, `IdUser`, `created_at`) VALUES
(1, 'Số điện thoại của shop có vấn đề nên ko liên lạc được', 27, '2020-12-21 09:09:05');

-- --------------------------------------------------------

--
-- Table structure for table `repbinhluan`
--

CREATE TABLE `repbinhluan` (
  `IdRepBinhLuan` int(10) UNSIGNED NOT NULL,
  `NoiDung` varchar(255) NOT NULL,
  `IdBinhLuan` int(10) UNSIGNED NOT NULL,
  `IdUser` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `repbinhluan`
--

INSERT INTO `repbinhluan` (`IdRepBinhLuan`, `NoiDung`, `IdBinhLuan`, `IdUser`, `created_at`, `updated_at`) VALUES
(2, 'sadsadsa', 3, 27, '2020-10-10 11:00:25', NULL),
(3, 'sadsadsa', 3, 27, '2020-10-10 11:00:25', NULL),
(4, 'còn bạn nhé', 31, 5, '2021-01-08 08:56:25', NULL),
(5, 'hihi', 31, 5, '2021-01-08 08:56:57', NULL),
(11, 'còn nhé bạn', 33, 2, '2021-01-11 09:14:02', NULL),
(12, 'chào bạn !', 30, 2, '2021-01-11 09:21:57', NULL),
(13, 'Còn nghe', 33, 2, '2021-01-11 09:22:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `IdSanPham` int(10) UNSIGNED NOT NULL,
  `TenSanPham` varchar(255) NOT NULL,
  `TenKhongDau` varchar(255) NOT NULL,
  `MoTa` varchar(255) NOT NULL,
  `Gia` float UNSIGNED NOT NULL,
  `SoLuong` int(10) UNSIGNED NOT NULL,
  `GiamGia` int(10) UNSIGNED DEFAULT 0,
  `IdTheLoai` int(10) UNSIGNED NOT NULL,
  `IdKieuSize` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`IdSanPham`, `TenSanPham`, `TenKhongDau`, `MoTa`, `Gia`, `SoLuong`, `GiamGia`, `IdTheLoai`, `IdKieuSize`, `created_at`, `updated_at`) VALUES
(1, 'Áo sơ mi nam', 'Ao-so-mi-nam', 'Áo sơ mi nam', 200000, 190, 0, 23, 2, '2020-12-14 13:04:19', '2020-12-20 11:05:29'),
(16, 'Áo sơ mi nữ', 'Ao-so-mi-nu', 'Áo sơ mi nữ chất lượng cao', 200000, 200, 10, 31, 2, '2020-12-14 13:04:19', NULL),
(17, 'Nịt da nam', 'Nit-da-nam', 'Nịt da nam xuất khẩu', 210000, 100, 10, 22, 4, '2020-12-14 16:16:47', '2021-01-07 04:27:26'),
(18, 'Áo sơ mi nam 1', 'Ao-so-mi-nam-1', 'Áo sơ mi nam', 200000, 200, 0, 23, 2, '2020-12-14 13:04:19', '2021-01-04 04:58:12'),
(20, 'Áo sơ mi nữ 1', 'Ao-so-mi-nu-1', 'Áo sơ mi nữ chất lượng cao', 200000, 200, 10, 31, 2, '2020-12-14 13:04:19', '2021-01-04 04:57:58'),
(21, 'Nịt da nam 1', 'Nit-da-nam-1', 'Nịt da nam xuất khẩu', 210000, 100, 10, 22, 4, '2020-12-14 16:16:47', '2021-01-04 04:56:32'),
(22, 'Áo sơ mi nam 3', 'Ao-so-mi-nam-3', 'Áo sơ mi nam', 200000, 200, 0, 23, 2, '2020-12-14 13:04:19', '2021-01-07 04:25:32'),
(25, 'Nịt da nam 6', 'Nit-da-nam', 'Nịt da nam xuất khẩu', 210000, 100, 10, 22, 4, '2020-12-14 16:16:47', '2020-12-20 11:05:56'),
(26, 'Áo sơ mi nam 7', 'Ao-so-mi-nam-7', 'Áo sơ mi nam', 200000, 200, 0, 38, 2, '2020-12-14 13:04:19', '2020-12-30 08:05:44'),
(44, 'Áo thun nam', 'Ao-thun-nam', 'Áo thun nam', 250000, 100, 0, 38, 2, '2020-12-29 16:07:22', '2020-12-29 16:12:54'),
(45, 'Áo thun ca rôô', 'Ao-thun-ca-roo', 'Áo thun ca rô có cổ', 200000, 100, 20, 38, 2, '2020-12-30 07:55:14', '2021-01-04 07:17:47'),
(68, 'Áo sơ mi nam nam', 'Ao-so-mi-nam-nam', 'Áo sơ mi nam nam', 150000, 90, 0, 23, 2, '2021-01-05 06:31:36', '2021-01-07 04:27:56');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham_size`
--

CREATE TABLE `sanpham_size` (
  `sanpham_IdSanPham` int(10) UNSIGNED NOT NULL,
  `size_IdSize` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sanpham_size`
--

INSERT INTO `sanpham_size` (`sanpham_IdSanPham`, `size_IdSize`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(16, 1),
(16, 2),
(16, 3),
(16, 4),
(44, 1),
(44, 2),
(44, 3),
(44, 4),
(44, 32),
(45, 1),
(45, 2),
(45, 3),
(45, 4),
(45, 32),
(68, 1),
(68, 2),
(68, 3);

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE `size` (
  `IdSize` int(10) UNSIGNED NOT NULL,
  `TenSize` varchar(255) NOT NULL,
  `IdKieuSize` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`IdSize`, `TenSize`, `IdKieuSize`, `created_at`, `updated_at`) VALUES
(1, 'S', 2, '2020-12-15 08:24:49', NULL),
(2, 'L', 2, '2020-12-15 08:24:49', NULL),
(3, 'M', 2, '2020-12-15 08:24:49', NULL),
(4, 'XL', 2, '2020-12-15 08:24:49', NULL),
(7, '28', 1, '2020-12-15 08:24:49', NULL),
(8, '29', 1, '2020-12-15 08:24:49', NULL),
(9, '30', 1, '2020-12-15 08:24:49', NULL),
(10, '31', 1, '2020-12-15 08:24:49', NULL),
(11, '32', 1, '2020-12-15 08:24:49', NULL),
(12, '33', 1, '2020-12-15 08:24:49', NULL),
(13, '34', 1, '2020-12-15 08:24:49', NULL),
(14, '36', 3, '2020-12-15 08:24:49', NULL),
(15, '37', 3, '2020-12-15 08:24:49', NULL),
(16, '38', 3, '2020-12-15 08:24:49', NULL),
(17, '39', 3, '2020-12-15 08:24:49', NULL),
(18, '40', 3, '2020-12-15 08:24:49', NULL),
(19, '41', 3, '2020-12-15 08:24:49', NULL),
(20, '42', 3, '2020-12-15 08:24:49', NULL),
(21, '43', 3, '2020-12-15 08:24:49', NULL),
(22, '44', 3, '2020-12-15 08:24:49', NULL),
(32, 'XXL', 2, '2020-12-24 04:59:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `IdSlide` int(10) UNSIGNED NOT NULL,
  `TenSlide` varchar(255) NOT NULL,
  `Hinh` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`IdSlide`, `TenSlide`, `Hinh`, `created_at`, `updated_at`) VALUES
(2, 'sự kiện black friday 1', './public/upload/slide/3j0mkblack1.jpg', '2020-12-12 04:09:08', '2020-12-12 10:42:40'),
(5, 'sự kiện black friday 2', './public/upload/slide/k162gblack2.png', '2020-12-12 04:13:59', '2020-12-12 11:18:24'),
(10, 'sự kiện black friday 3', './public/upload/slide/rtvaxblack.jpg', '2020-12-12 11:00:37', NULL),
(13, 'sự kiện giáng sinh 12-2020', './public/upload/slide/u4xibnoel1-12-2020.jpg', '2020-12-12 11:21:29', NULL),
(14, 'sự kiện giáng sinh 12-2020 1', './public/upload/slide/5qzronoel2-12-2020.jpg', '2020-12-12 11:21:59', NULL),
(15, 'sự kiện giáng sinh 12-2020 2', './public/upload/slide/vijvknoel-12-2020.jpg', '2020-12-12 11:25:32', '2020-12-19 15:52:09');

-- --------------------------------------------------------

--
-- Table structure for table `theloai`
--

CREATE TABLE `theloai` (
  `IdTheLoai` int(10) UNSIGNED NOT NULL,
  `TenTheLoai` varchar(255) NOT NULL,
  `TenKhongDau` varchar(255) NOT NULL,
  `AnhDaiDien` varchar(255) NOT NULL,
  `IdDanhMuc` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `theloai`
--

INSERT INTO `theloai` (`IdTheLoai`, `TenTheLoai`, `TenKhongDau`, `AnhDaiDien`, `IdDanhMuc`, `created_at`, `updated_at`) VALUES
(22, 'Nịt Nam', 'Nit-Nam', './public/upload/theloai/2zf04phukien.jpg', 51, '2020-12-12 02:06:26', '2020-12-12 02:57:25'),
(23, 'Áo Sơ Mi Nam', 'Ao-So-Mi-Nam', './public/upload/theloai/epu3bsp1.jpg', 42, '2020-12-12 02:07:22', NULL),
(24, 'Giày Nam', 'Giay-Nam', './public/upload/theloai/shcb1giaydep.jpg', 49, '2020-12-12 02:08:28', NULL),
(31, 'Áo Sơ Mi Nữ', 'Ao-So-Mi-Nu', './public/upload/theloai/ajrsqsp6.png', 42, '2020-12-14 13:01:56', '2020-12-29 16:16:22'),
(38, 'Áo thun nam', 'Ao-thun-nam', './public/upload/theloai/hs78gaothunden.jpg', 42, '2020-12-29 16:12:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `IdUser` int(10) UNSIGNED NOT NULL,
  `HoTen` varchar(255) NOT NULL,
  `SoDienThoai` varchar(15) DEFAULT NULL,
  `DiaChi` varchar(255) DEFAULT NULL,
  `TenDangNhap` varchar(255) NOT NULL,
  `MatKhau` varchar(255) NOT NULL,
  `VaiTro` varchar(100) NOT NULL,
  `TrangThai` int(11) DEFAULT 0,
  `MaKichHoat` varchar(255) DEFAULT NULL,
  `GioiTinh` varchar(20) DEFAULT NULL,
  `NgaySinh` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ngay_kichhoat` timestamp NULL DEFAULT NULL,
  `AnhDaiDien` varchar(255) DEFAULT NULL,
  `ngay_khoa` timestamp NULL DEFAULT NULL,
  `ngay_mokhoa` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`IdUser`, `HoTen`, `SoDienThoai`, `DiaChi`, `TenDangNhap`, `MatKhau`, `VaiTro`, `TrangThai`, `MaKichHoat`, `GioiTinh`, `NgaySinh`, `created_at`, `updated_at`, `ngay_kichhoat`, `AnhDaiDien`, `ngay_khoa`, `ngay_mokhoa`) VALUES
(1, 'Nguyễn Văn Trung', '0337361667', 'K82/H10/34 Nguyễn Văn Linh , Nam Dương , Đà Nẵngg', 'nguyenvantrung070tbh@gmail.com', '$2y$10$1kcrQ58VejJ1T437Udt/3u7FXDA0ZX8JY2F7gTdhkXIicTicch7CO', 'Admin', 0, NULL, 'Nam', '1998-12-31', '2020-12-16 07:40:29', '2020-12-20 17:11:25', '2020-12-16 08:30:00', './public/upload/taikhoan/ze9ahtrung.jpg', NULL, NULL),
(2, 'Tống Lê Hoàng Yến', '0702470565', 'K442 Hoàng Diệu , Đà Nẵng', 'tonglehoangyen0206@gmail.com', '$2y$10$5RiwNSDu6HCSwf2epBiNPexDrvb0ynzUky1P/9czHgKI8RWbL4K66', 'Quản trị', 1, NULL, 'Nữ', '1998-06-02', '2021-01-03 01:56:09', '2020-12-16 07:40:29', '2020-12-16 08:30:00', './public/upload/taikhoan/iwfdfperson1.jpeg', NULL, NULL),
(4, 'Bùi Thị Xi Ti', '0905002119', '555 Tôn Đức Thắng , Đà Nẵng', 'buithixiti@gmail.com', '$2y$10$5RiwNSDu6HCSwf2epBiNPexDrvb0ynzUky1P/9czHgKI8RWbL4K66', 'Người dùng', 3, NULL, 'Nữ', '1998-08-28', '2020-12-16 07:40:29', '2020-12-16 07:40:29', '2020-12-16 07:40:29', './public/upload/taikhoan/2ja9uapple watch.jpg', NULL, NULL),
(5, 'Nguyễn Như Ý Ly', '0305020292', '143 Phan Đình Phùng , Phước Hòa , Tam Kỳ', 'nguyennhuyly@gmail.com', '$2y$10$AO2NawwG.MtiFpsH6GsEiu/TjvvEwoi9wgj.Dmv6NQ4AJq/o.o216', 'Người dùng', 2, NULL, 'Nữ', '1998-12-09', '2020-12-16 07:40:29', '2021-01-11 04:46:01', '2020-12-16 07:40:29', './public/upload/taikhoan/2ja9uapple watch.jpg', '2021-01-11 06:17:41', '2021-01-12 06:17:41'),
(7, 'nguyễn văn trung a', '0337983712', 'k82/h10/34 nguyễn văn linh , đà nẵng', 'trung@gmail.com', '$2y$10$lx2wQUX1./WOP/HHJEWBfu5iCC.lNQbR62qMmGlY7W4wZ8WHsz4Rq', 'Quản trị', 0, '1nrjagrbvd2die8k8aksswflk9s1dsibddd7g76sypjqk9d498u8hd1ga4t0ash1n0d57djdadznhs3hh9a3mdugjqsa8avsy1faahkkjjah35ijnsxhskcs7ahjaoaaba5a7akh', '', '0000-00-00', '2020-12-17 04:02:53', NULL, NULL, './public/upload/taikhoan/gh7abgiaydep1.jpg', NULL, NULL),
(10, 'nguyễn văn trung', '0337371267', 'K82/H10/34 Nguyen Van Linh , Da Nang', 'lapngungoc@gmail.com', '$2y$10$BTrSBTCz2O44Vk4PgCJTd.gmpM88urL6nMLXN4cd3iwW1ry4IbFLW', 'Quản trị', 0, 'd5iejfdajcak9pa32addhhdsaghh7gjdk1ahr83fd5hhszqsd8sakujq9d8kadxdyi1ugs63jaysvhn4ga1ja1akanssans9mdb78st7bla0sas7nk9ohj7v014awrdk5kjbiha8', '', '0000-00-00', '2020-12-17 04:05:52', NULL, NULL, './public/upload/taikhoan/j1sahaothun.jpg', NULL, NULL),
(15, 'Nguyen Van Trung', '0337371657', 'K82/H10/34 Nguyen Van Linh , Da Nang ', 'nguyenvantrung0dsa7tbh@gmail.com', '$2y$10$UHP3gX9YBMPQunxcpx0m3e0xFPz2uIVDpyVts6lsZXom.j4GS/6R.', 'Quản trị', 0, 'z6md7tpdhbnjs9bagdkadaaskshsk7hnq1aaay5kuuaaj75dkj0ins27jsr13da1x8d5j4dignihya9fka3vkdqjgkaraa8ljdo0a8sv8gsfaes1hjs1d9cb7d49h8hhwdhs3hsa', 'Nam', '1998-12-31', '2020-12-17 04:23:40', NULL, NULL, './public/upload/taikhoan/wsvqpaothun.jpg', NULL, NULL),
(17, 'Nguyen Van Trung', '0337371123', 'K82/H10/34 Nguyen Van Linh , Da Nang', 'nguyenvantrung07123tbh@gmail.com', '$2y$10$XdZCq0Cb6lrDpOUX6HX8g.N6vHKru/10I0UhDdO9SBB9NvmPhO6h6', 'Quản trị', 0, 'had3hdjz5sah1faqj8ah4rada81dajk87ssygi0dah78kddj8dnnf7iu5a3kh1kkpss9dheh3vn9q9sb9uvgrakaljkg2bwj71hsiajxcagbajnsykhaaa1stds4sa5d0domd67s', 'Nam', '1998-12-31', '2020-12-17 07:31:43', NULL, NULL, './public/upload/taikhoan/521nrtrung.jpg', NULL, NULL),
(18, 'Nguyen Van Trung', '0902930922', 'K82/H10/34 Nguyen Van Linh , Da Nang ', 'nguyenvantrung03217tbh@gmail.com', '$2y$10$EX79AVa36rfEt8iDyNwtsud6SSntYxlORu.pRc9RvH6iq8cHxNBNS', 'Quản trị', 0, 'jdpa1kahhmaijdhss7b3knavsnsasdhdsa0geak77q1saygaso5ahdf18h2aascgs8d55ja1adk978d93sruunk3r9kj9v68hajqagk0jijdfhwikd7jl8td4bndba1szhxy4dah', 'Nam', '1998-12-31', '2020-12-17 07:37:39', NULL, NULL, './public/upload/taikhoan/7vs0ntrung.jpg', NULL, NULL),
(19, 'nguyễn văn trung', '0337371327', 'K82/H10/34 Nguyen Van Linh , Da Nang', 'nguyenvantrun213g07tbh@gmail.com', '$2y$10$20//xBYl3RFfaxB2h68Bm.HZHZix.kDxvCAPqMU3AOMOEhHmBeDAm', 'Quản trị', 0, 'yddddjansv850hj5asahsfzadnaisa117hdkadjhgdhsaiku914shb7orlgs4hq9kaj3d2b3j98sjbsiyx6dwacfuk8a87avsg3ntp8aamjadg7d95ah71k1ek0kahjshansdrqk', 'Nam', '1998-12-31', '2020-12-17 07:45:12', NULL, NULL, './public/upload/taikhoan/h1hkdgiaydep1.jpg', NULL, NULL),
(20, 'Nguyen Van Trung', '0337223667', 'K82/H10/34 Nguyen Van Linh , Da Nang ', 'nguyenvantrung072tbh@gmail.com', '$2y$10$g.hn49AHdiZblg5eH.iXYeKq0ugm/AsrtfV1Ac7.NCIoddSoIaPLC', 'Quản trị', NULL, NULL, 'Nam', '1998-12-31', '2020-12-17 07:59:24', NULL, '2020-12-17 02:06:57', './public/upload/taikhoan/ga9nutrung.jpg', NULL, NULL),
(21, 'Nguyễn Văn Trung', '0337222667', 'k82/h10/34 nguyễn văn linh , đà nẵng', 'nguyenvantrung07s2tbh@gmail.com', '$2y$10$GyfBwMZH/M4RDdC677znOe6vBLjtGXAzQIPacGnERyL/VmWv5J7e.', 'Quản trị', 3, NULL, 'Nam', '1998-12-31', '2020-12-17 08:14:09', NULL, '2020-12-17 02:15:02', './public/upload/taikhoan/2ja9uapple watch.jpg', NULL, NULL),
(27, 'Nguyễn Văn Trung', '0337371667', 'k82/h10/34 nguyễn văn linh , thanh khê , đà nẵng , việt nam', 'nguyenvantrung070123tbh@gmail.com', '$2y$10$efUMyBFxbXJ7Lta9nY1I9.cBEcuSvKGLR2nvxwZAxrEayFY8Ncs0O', 'Người dùng', 1, NULL, 'Nam', '1998-12-31', '2021-01-05 03:32:12', '2021-01-11 04:49:04', '2020-12-20 19:53:39', './public/upload/taikhoan/d5gofperson1.jpeg', NULL, NULL),
(29, 'Nguyễn Văn Trung', '0702470554', 'K82/H10/34 Nguyễn văn linh', 'nguyenvantrung07tbh@gmail.com', '$2y$10$fBHPGBYguDMLp9APfKo/3uOUYA0CROEgiSwiRnQlbxxrQ4MkQTN1q', 'Người dùng', 1, NULL, 'Nam', '1999-01-13', '2021-01-11 08:03:07', NULL, '2021-01-11 07:43:51', './public/upload/taikhoan/t96eg013wia9nujlogo.png', NULL, NULL),
(30, 'Lập Lầm Lâm', NULL, NULL, 'daoquanlap98@gmail.com', '$2y$10$Vsk/9YP5/uMepdWIqGY5sOKBLgqLxtHPYLqapiEnredQyHJrnCz.u', 'Người dùng', 0, '99x0lfj82avvf5tp4bxr5ybbtbz6nsv4i9kufqjdhoei2dlnyzkn3cpg1lsczn94uy2gomdqflto2sb7sm3wwc21rhml1qy7ociyo4093s0p1jvtfw8u1k50mx3zhr67uki6p3t507q46g5ehxwziggprkeaqr8neavdw6jxmahaud878jec', NULL, NULL, '2021-01-11 08:06:51', NULL, NULL, './public/upload/taikhoan/anhdaidien.png', NULL, NULL),
(31, 'Lập Đệp Trai', '0354176727', '461/35 Hải Phòng , Đà Nẵng', 'daoquanglap98@gmail.com', '$2y$10$XQH7MpJrub9.RgfXk0kf0.lRH4KG7yJv6lCI.Fj0bxrE2MBtqcMmS', 'Người dùng', 1, NULL, 'Nam', '1998-01-20', '2021-01-11 08:13:19', NULL, '2021-01-11 08:09:26', './public/upload/taikhoan/anhdaidien.png', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `binhluan`
--
ALTER TABLE `binhluan`
  ADD PRIMARY KEY (`IdBinhLuan`),
  ADD KEY `binhluan_ibfk_1` (`IdUser`),
  ADD KEY `binhluan_ibfk_2` (`IdSanPham`);

--
-- Indexes for table `danhmuc`
--
ALTER TABLE `danhmuc`
  ADD PRIMARY KEY (`IdDanhMuc`),
  ADD UNIQUE KEY `unique_TenDanhMuc` (`TenDanhMuc`);

--
-- Indexes for table `donhang`
--
ALTER TABLE `donhang`
  ADD PRIMARY KEY (`IdDonHang`),
  ADD KEY `donhang_ibfk_1` (`IdUser`);

--
-- Indexes for table `donhang_sp`
--
ALTER TABLE `donhang_sp`
  ADD PRIMARY KEY (`IdDonHangSp`),
  ADD KEY `donhang_sp_ibfk_1` (`IdDonHang`);

--
-- Indexes for table `hinhanh`
--
ALTER TABLE `hinhanh`
  ADD PRIMARY KEY (`IdHinhAnh`);

--
-- Indexes for table `kieusize`
--
ALTER TABLE `kieusize`
  ADD PRIMARY KEY (`IdKieuSize`);

--
-- Indexes for table `phanhoi`
--
ALTER TABLE `phanhoi`
  ADD PRIMARY KEY (`IdPhanHoi`),
  ADD KEY `phanhoi_ibfk_1` (`IdUser`);

--
-- Indexes for table `repbinhluan`
--
ALTER TABLE `repbinhluan`
  ADD PRIMARY KEY (`IdRepBinhLuan`),
  ADD KEY `IdBinhLuan` (`IdBinhLuan`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`IdSanPham`),
  ADD UNIQUE KEY `unique_TenSanPham` (`TenSanPham`),
  ADD KEY `sanpham_ibfk_1` (`IdTheLoai`),
  ADD KEY `sanpham_ibfk_2` (`IdKieuSize`);

--
-- Indexes for table `sanpham_size`
--
ALTER TABLE `sanpham_size`
  ADD PRIMARY KEY (`sanpham_IdSanPham`,`size_IdSize`),
  ADD KEY `fk_sanpham_has_size_size1_idx` (`size_IdSize`),
  ADD KEY `fk_sanpham_has_size_sanpham1_idx` (`sanpham_IdSanPham`);

--
-- Indexes for table `size`
--
ALTER TABLE `size`
  ADD PRIMARY KEY (`IdSize`),
  ADD KEY `size_ibfk_1` (`IdKieuSize`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`IdSlide`),
  ADD UNIQUE KEY `unique_TenSlide` (`TenSlide`);

--
-- Indexes for table `theloai`
--
ALTER TABLE `theloai`
  ADD PRIMARY KEY (`IdTheLoai`),
  ADD UNIQUE KEY `unique_TenTheLoai` (`TenTheLoai`),
  ADD KEY `theloai_ibfk_1` (`IdDanhMuc`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`IdUser`),
  ADD UNIQUE KEY `unique_TenDangNhap` (`TenDangNhap`),
  ADD UNIQUE KEY `unique_sodienthoai` (`SoDienThoai`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `binhluan`
--
ALTER TABLE `binhluan`
  MODIFY `IdBinhLuan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `danhmuc`
--
ALTER TABLE `danhmuc`
  MODIFY `IdDanhMuc` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `donhang`
--
ALTER TABLE `donhang`
  MODIFY `IdDonHang` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `donhang_sp`
--
ALTER TABLE `donhang_sp`
  MODIFY `IdDonHangSp` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `hinhanh`
--
ALTER TABLE `hinhanh`
  MODIFY `IdHinhAnh` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `kieusize`
--
ALTER TABLE `kieusize`
  MODIFY `IdKieuSize` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `phanhoi`
--
ALTER TABLE `phanhoi`
  MODIFY `IdPhanHoi` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `repbinhluan`
--
ALTER TABLE `repbinhluan`
  MODIFY `IdRepBinhLuan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `IdSanPham` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `size`
--
ALTER TABLE `size`
  MODIFY `IdSize` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `IdSlide` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `theloai`
--
ALTER TABLE `theloai`
  MODIFY `IdTheLoai` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `IdUser` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `binhluan`
--
ALTER TABLE `binhluan`
  ADD CONSTRAINT `binhluan_ibfk_1` FOREIGN KEY (`IdUser`) REFERENCES `users` (`IdUser`) ON DELETE CASCADE,
  ADD CONSTRAINT `binhluan_ibfk_2` FOREIGN KEY (`IdSanPham`) REFERENCES `sanpham` (`IdSanPham`) ON DELETE CASCADE;

--
-- Constraints for table `donhang`
--
ALTER TABLE `donhang`
  ADD CONSTRAINT `donhang_ibfk_1` FOREIGN KEY (`IdUser`) REFERENCES `users` (`IdUser`) ON DELETE CASCADE;

--
-- Constraints for table `donhang_sp`
--
ALTER TABLE `donhang_sp`
  ADD CONSTRAINT `donhang_sp_ibfk_1` FOREIGN KEY (`IdDonHang`) REFERENCES `donhang` (`IdDonHang`) ON DELETE CASCADE;

--
-- Constraints for table `phanhoi`
--
ALTER TABLE `phanhoi`
  ADD CONSTRAINT `phanhoi_ibfk_1` FOREIGN KEY (`IdUser`) REFERENCES `users` (`IdUser`) ON DELETE CASCADE;

--
-- Constraints for table `repbinhluan`
--
ALTER TABLE `repbinhluan`
  ADD CONSTRAINT `repbinhluan_ibfk_1` FOREIGN KEY (`IdBinhLuan`) REFERENCES `binhluan` (`IdBinhLuan`) ON DELETE CASCADE;

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `sanpham_ibfk_1` FOREIGN KEY (`IdTheLoai`) REFERENCES `theloai` (`IdTheLoai`) ON DELETE CASCADE,
  ADD CONSTRAINT `sanpham_ibfk_2` FOREIGN KEY (`IdKieuSize`) REFERENCES `kieusize` (`IdKieuSize`) ON DELETE CASCADE;

--
-- Constraints for table `sanpham_size`
--
ALTER TABLE `sanpham_size`
  ADD CONSTRAINT `fk_sanpham_has_size_sanpham1` FOREIGN KEY (`sanpham_IdSanPham`) REFERENCES `sanpham` (`IdSanPham`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_sanpham_has_size_size1` FOREIGN KEY (`size_IdSize`) REFERENCES `size` (`IdSize`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `size`
--
ALTER TABLE `size`
  ADD CONSTRAINT `size_ibfk_1` FOREIGN KEY (`IdKieuSize`) REFERENCES `kieusize` (`IdKieuSize`) ON DELETE CASCADE;

--
-- Constraints for table `theloai`
--
ALTER TABLE `theloai`
  ADD CONSTRAINT `theloai_ibfk_1` FOREIGN KEY (`IdDanhMuc`) REFERENCES `danhmuc` (`IdDanhMuc`) ON DELETE CASCADE;
